
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `accounting_releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounting_releases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `release_id` bigint(20) unsigned NOT NULL,
  `invoice_id` bigint(20) unsigned DEFAULT NULL,
  `payment_status` enum('unpaid','partial','paid','overdue') NOT NULL,
  `amount_due` decimal(10,2) DEFAULT NULL,
  `amount_paid` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_date` date DEFAULT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `payment_reference` varchar(255) DEFAULT NULL,
  `verified_by` bigint(20) unsigned NOT NULL,
  `verified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `can_release` tinyint(1) NOT NULL DEFAULT 0,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounting_releases_release_id_unique` (`release_id`),
  KEY `accounting_releases_release_id_index` (`release_id`),
  KEY `accounting_releases_payment_status_index` (`payment_status`),
  KEY `accounting_releases_verified_by_index` (`verified_by`),
  CONSTRAINT `accounting_releases_release_id_foreign` FOREIGN KEY (`release_id`) REFERENCES `releases` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounting_releases` WRITE;
/*!40000 ALTER TABLE `accounting_releases` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounting_releases` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `approval_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `approval_histories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `approvable_type` varchar(255) NOT NULL COMMENT 'polymorphic',
  `approvable_id` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned NOT NULL,
  `action` varchar(50) NOT NULL COMMENT 'approved, rejected, reviewed',
  `previous_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `approved_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `approval_histories_approvable_type_approvable_id_index` (`approvable_type`,`approvable_id`),
  KEY `approval_histories_approved_by_index` (`approved_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `approval_histories` WRITE;
/*!40000 ALTER TABLE `approval_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `approval_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `assignments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assignments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `assigned_to` bigint(20) unsigned NOT NULL COMMENT 'user_id',
  `assigned_by` bigint(20) unsigned NOT NULL,
  `assigned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `scheduled_date` date DEFAULT NULL,
  `scheduled_time` time DEFAULT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `status` varchar(50) NOT NULL,
  `estimated_duration` int(11) DEFAULT NULL COMMENT 'in hours',
  `actual_duration` int(11) DEFAULT NULL COMMENT 'in hours',
  `location` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `started_at` timestamp NULL DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assignments_job_order_id_index` (`job_order_id`),
  KEY `assignments_assigned_to_index` (`assigned_to`),
  KEY `assignments_scheduled_date_index` (`scheduled_date`),
  KEY `assignments_status_index` (`status`),
  CONSTRAINT `assignments_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `assignments` WRITE;
/*!40000 ALTER TABLE `assignments` DISABLE KEYS */;
/*!40000 ALTER TABLE `assignments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `old_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_values`)),
  `new_values` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_values`)),
  `changed_fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`changed_fields`)),
  `ip_address` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `url` varchar(500) DEFAULT NULL,
  `method` varchar(10) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_index` (`user_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_model_type_model_id_index` (`model_type`,`model_id`),
  KEY `audit_logs_created_at_index` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=559 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (475,1,'LOGIN','User',1,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','2sN5XhusoDct2pIlIwvY3kiLAcfwx8bpX35Pk0Nn','http://127.0.0.1:8000/login','POST','User logged in','2026-03-15 23:48:58'),(476,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/clean_backup_2026_03_16_07_47_59.sql','GET','Downloaded backup: clean_backup_2026_03_16_07_47_59.sql','2026-03-15 23:49:24'),(477,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"clean_backup_2026_03_16_07_47_59.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-15 23:49:31'),(478,1,'DELETE','User',22,'{\"name\":\"TEST_RESTORE_1773618406\",\"email\":\"restore_test_1773618406@test.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/22','DELETE','Admin deleted user: TEST_RESTORE_1773618406 (restore_test_1773618406@test.com)','2026-03-15 23:49:45'),(479,1,'DELETE','User',23,'{\"name\":\"TEST_RESTORE_1773618421\",\"email\":\"restore_test_1773618421@test.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/23','DELETE','Admin deleted user: TEST_RESTORE_1773618421 (restore_test_1773618421@test.com)','2026-03-15 23:49:50'),(480,1,'DELETE','User',18,'{\"name\":\"TEST_USER_07:45:40\",\"email\":\"test_1773618340@test.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/18','DELETE','Admin deleted user: TEST_USER_07:45:40 (test_1773618340@test.com)','2026-03-15 23:49:54'),(481,1,'DELETE','User',19,'{\"name\":\"TEST_USER_07:45:55\",\"email\":\"test_1773618355@test.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/19','DELETE','Admin deleted user: TEST_USER_07:45:55 (test_1773618355@test.com)','2026-03-15 23:49:59'),(482,1,'DELETE','User',21,'{\"name\":\"TEST_USER_07:46:24\",\"email\":\"test_1773618384@test.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/21','DELETE','Admin deleted user: TEST_USER_07:46:24 (test_1773618384@test.com)','2026-03-15 23:50:03'),(483,1,'DELETE','User',20,'{\"name\":\"TEST_USER_07:46:12\",\"email\":\"test_1773618372@test.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/20','DELETE','Admin deleted user: TEST_USER_07:46:12 (test_1773618372@test.com)','2026-03-15 23:50:06'),(484,1,'DELETE','User',17,'{\"name\":\"testing\",\"email\":\"test@example.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/17','DELETE','Admin deleted user: testing (test@example.com)','2026-03-15 23:50:11'),(485,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_07_50.sql','2026-03-15 23:50:22'),(486,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_07_50.sql','GET','Downloaded backup: backup_2026_03_16_07_50.sql','2026-03-15 23:50:26'),(487,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_07_42.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-15 23:50:38'),(488,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_07_50.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-15 23:50:56'),(489,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/verify_2026_03_16_07_55_41.sql','GET','Downloaded backup: verify_2026_03_16_07_55_41.sql','2026-03-15 23:56:54'),(490,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/verify_2026_03_16_07_55_41.sql','DELETE','Deleted backup: verify_2026_03_16_07_55_41.sql','2026-03-15 23:56:59'),(491,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_07_50.sql','DELETE','Deleted backup: backup_2026_03_16_07_50.sql','2026-03-15 23:57:02'),(492,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/clean_backup_2026_03_16_07_47_59.sql','DELETE','Deleted backup: clean_backup_2026_03_16_07_47_59.sql','2026-03-15 23:57:06'),(493,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_07_37.sql','DELETE','Deleted backup: backup_2026_03_16_07_37.sql','2026-03-15 23:57:12'),(494,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/clean_backup_2026_03_16_07_47_42.sql','DELETE','Deleted backup: clean_backup_2026_03_16_07_47_42.sql','2026-03-15 23:57:17'),(495,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/clean_backup_2026_03_16_07_47_22.sql','DELETE','Deleted backup: clean_backup_2026_03_16_07_47_22.sql','2026-03-15 23:57:20'),(496,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/clean_backup_2026_03_16_07_47_00.sql','DELETE','Deleted backup: clean_backup_2026_03_16_07_47_00.sql','2026-03-15 23:57:25'),(497,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/clean_backup_2026_03_16_07_46_46.sql','DELETE','Deleted backup: clean_backup_2026_03_16_07_46_46.sql','2026-03-15 23:57:29'),(498,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/test_backup_2026_03_16_07_46_25.sql','DELETE','Deleted backup: test_backup_2026_03_16_07_46_25.sql','2026-03-15 23:57:33'),(499,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/test_backup_2026_03_16_07_46_12.sql','DELETE','Deleted backup: test_backup_2026_03_16_07_46_12.sql','2026-03-15 23:57:37'),(500,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/test_backup_2026_03_16_07_45_55.sql','DELETE','Deleted backup: test_backup_2026_03_16_07_45_55.sql','2026-03-15 23:57:42'),(501,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/test_backup_2026_03_16_07_45_40.sql','DELETE','Deleted backup: test_backup_2026_03_16_07_45_40.sql','2026-03-15 23:57:46'),(502,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_07_42.sql','DELETE','Deleted backup: backup_2026_03_16_07_42.sql','2026-03-15 23:57:50'),(503,1,'CREATE','User',24,NULL,'{\"name\":\"testing\",\"email\":\"test@example.com\",\"role_id\":\"14\",\"is_active\":true}','[\"name\",\"email\",\"role_id\",\"is_active\",\"password\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users','POST','Admin created new user: testing (test@example.com)','2026-03-15 23:58:24'),(504,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_07_58.sql','2026-03-15 23:58:38'),(505,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_07_58.sql','GET','Downloaded backup: backup_2026_03_16_07_58.sql','2026-03-15 23:58:42'),(506,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"verify_2026_03_16_07_55_41.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-15 23:58:49'),(507,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/users\",\"status_code\":302,\"payload\":{\"name\":\"asdasdas\",\"email\":\"asdasdadas@gmail.com\",\"role_id\":\"15\",\"status\":\"active\"}}','[\"name\",\"email\",\"role_id\",\"status\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users','POST','CREATE on admin/users via admin.users.store (fields: name, email, role_id, status)','2026-03-16 00:00:33'),(508,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/users\",\"status_code\":302,\"payload\":{\"name\":\"testing1\",\"email\":\"test@example.com\",\"role_id\":\"15\",\"status\":\"active\"}}','[\"name\",\"email\",\"role_id\",\"status\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users','POST','CREATE on admin/users via admin.users.store (fields: name, email, role_id, status)','2026-03-16 00:00:55'),(509,1,'DELETE','User',25,'{\"name\":\"TEST_USER_20260316080423\",\"email\":\"test20260316080423@test.local\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/25','DELETE','Admin deleted user: TEST_USER_20260316080423 (test20260316080423@test.local)','2026-03-16 00:06:56'),(510,1,'DELETE','User',26,'{\"name\":\"TEST_USER_20260316080516\",\"email\":\"test20260316080516@test.local\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/26','DELETE','Admin deleted user: TEST_USER_20260316080516 (test20260316080516@test.local)','2026-03-16 00:06:59'),(511,1,'DELETE','User',24,'{\"name\":\"testing\",\"email\":\"test@example.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/24','DELETE','Admin deleted user: testing (test@example.com)','2026-03-16 00:07:03'),(512,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/proper_test_20260316080536.sql','DELETE','Deleted backup: proper_test_20260316080536.sql','2026-03-16 00:07:11'),(513,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/test_restore_20260316080516.sql','DELETE','Deleted backup: test_restore_20260316080516.sql','2026-03-16 00:07:15'),(514,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/test_restore_20260316080423.sql','DELETE','Deleted backup: test_restore_20260316080423.sql','2026-03-16 00:07:20'),(515,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_07_58.sql','DELETE','Deleted backup: backup_2026_03_16_07_58.sql','2026-03-16 00:07:24'),(516,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_08.sql','DELETE','Deleted backup: backup_2026_03_16_08_08.sql','2026-03-16 00:14:24'),(517,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_07.sql','DELETE','Deleted backup: backup_2026_03_16_08_07.sql','2026-03-16 00:14:28'),(518,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_14.sql','2026-03-16 00:14:32'),(519,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_08_14.sql','GET','Downloaded backup: backup_2026_03_16_08_14.sql','2026-03-16 00:14:36'),(520,1,'CREATE','User',27,NULL,'{\"name\":\"testing\",\"email\":\"test@example.com\",\"role_id\":\"14\",\"is_active\":true}','[\"name\",\"email\",\"role_id\",\"is_active\",\"password\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users','POST','Admin created new user: testing (test@example.com)','2026-03-16 00:14:59'),(521,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_15.sql','2026-03-16 00:15:11'),(522,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_08_15.sql','GET','Downloaded backup: backup_2026_03_16_08_15.sql','2026-03-16 00:15:15'),(523,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_08_14.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-16 00:15:20'),(524,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_08_14.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-16 00:15:41'),(525,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_08_15.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-16 00:16:01'),(526,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_15.sql','DELETE','Deleted backup: backup_2026_03_16_08_15.sql','2026-03-16 00:21:09'),(527,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_14.sql','DELETE','Deleted backup: backup_2026_03_16_08_14.sql','2026-03-16 00:21:13'),(528,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_21.sql','2026-03-16 00:21:16'),(529,1,'CREATE','User',28,NULL,'{\"name\":\"DELETE_ME\",\"email\":\"delete@gmail.com\",\"role_id\":\"15\",\"is_active\":true}','[\"name\",\"email\",\"role_id\",\"is_active\",\"password\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users','POST','Admin created new user: DELETE_ME (delete@gmail.com)','2026-03-16 00:21:38'),(530,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_21.sql','2026-03-16 00:21:47'),(531,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_08_21.sql','GET','Downloaded backup: backup_2026_03_16_08_21.sql','2026-03-16 00:21:56'),(532,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_21.sql','2026-03-16 00:21:58'),(533,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_22.sql','2026-03-16 00:22:07'),(534,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_08_22.sql','GET','Downloaded backup: backup_2026_03_16_08_22.sql','2026-03-16 00:22:12'),(535,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_08_21.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-16 00:22:23'),(536,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_08_22.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-16 00:22:49'),(537,1,'DELETE','User',28,'{\"name\":\"DELETE_ME\",\"email\":\"delete@gmail.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/28','DELETE','Admin deleted user: DELETE_ME (delete@gmail.com)','2026-03-16 00:27:01'),(538,1,'DELETE','User',27,'{\"name\":\"testing\",\"email\":\"test@example.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/27','DELETE','Admin deleted user: testing (test@example.com)','2026-03-16 00:27:05'),(539,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_22.sql','DELETE','Deleted backup: backup_2026_03_16_08_22.sql','2026-03-16 00:27:15'),(540,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_21.sql','DELETE','Deleted backup: backup_2026_03_16_08_21.sql','2026-03-16 00:27:19'),(541,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_27.sql','2026-03-16 00:27:23'),(542,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_08_27.sql','GET','Downloaded backup: backup_2026_03_16_08_27.sql','2026-03-16 00:27:26'),(543,1,'CREATE','User',29,NULL,'{\"name\":\"DELETE_ME\",\"email\":\"delete@gmail.com\",\"role_id\":\"15\",\"is_active\":true}','[\"name\",\"email\",\"role_id\",\"is_active\",\"password\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users','POST','Admin created new user: DELETE_ME (delete@gmail.com)','2026-03-16 00:27:51'),(544,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_27.sql','2026-03-16 00:28:00'),(545,1,'CREATE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','Created database backup: backup_2026_03_16_08_28.sql','2026-03-16 00:28:03'),(546,1,'VIEW','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/download/backup_2026_03_16_08_28.sql','GET','Downloaded backup: backup_2026_03_16_08_28.sql','2026-03-16 00:28:07'),(547,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/restore\",\"status_code\":302,\"payload\":{\"backup_file\":{},\"uploaded_files\":{\"backup_file\":\"backup_2026_03_16_08_27.sql\"}}}','[\"backup_file\",\"uploaded_files\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/restore','POST','CREATE on admin/settings/backup/restore via admin.settings.backup.restore (fields: backup_file, uploaded_files)','2026-03-16 00:28:23'),(548,1,'DELETE','User',29,'{\"name\":\"DELETE_ME\",\"email\":\"delete@gmail.com\",\"is_active\":true}',NULL,'[\"deleted\"]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/users/29','DELETE','Admin deleted user: DELETE_ME (delete@gmail.com)','2026-03-16 00:31:22'),(549,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_28.sql','DELETE','Deleted backup: backup_2026_03_16_08_28.sql','2026-03-16 00:31:35'),(550,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/backup_2026_03_16_08_27.sql','DELETE','Deleted backup: backup_2026_03_16_08_27.sql','2026-03-16 00:31:39'),(551,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/2026-03-16-08-46-01.zip','DELETE','Deleted backup: 2026-03-16-08-46-01.zip','2026-03-16 00:49:29'),(552,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/create\",\"status_code\":302,\"payload\":[]}','[]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','CREATE on admin/settings/backup/create via admin.settings.backup.create (fields: no payload fields)','2026-03-16 00:52:49'),(553,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/create\",\"status_code\":302,\"payload\":[]}','[]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','CREATE on admin/settings/backup/create via admin.settings.backup.create (fields: no payload fields)','2026-03-16 00:52:56'),(554,1,'DELETE','Backup',0,NULL,NULL,NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/delete/2026-03-16-08-51-15.zip','DELETE','Deleted backup: 2026-03-16-08-51-15.zip','2026-03-16 00:53:04'),(555,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/create\",\"status_code\":302,\"payload\":[]}','[]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','CREATE on admin/settings/backup/create via admin.settings.backup.create (fields: no payload fields)','2026-03-16 00:53:07'),(556,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/create\",\"status_code\":302,\"payload\":[]}','[]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','CREATE on admin/settings/backup/create via admin.settings.backup.create (fields: no payload fields)','2026-03-16 00:53:13'),(557,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/create\",\"status_code\":302,\"payload\":[]}','[]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','CREATE on admin/settings/backup/create via admin.settings.backup.create (fields: no payload fields)','2026-03-16 00:53:20'),(558,1,'CREATE','Unknown',0,NULL,'{\"route\":\"admin\\/settings\\/backup\\/create\",\"status_code\":302,\"payload\":[]}','[]','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1','http://127.0.0.1:8000/admin/settings/backup/create','POST','CREATE on admin/settings/backup/create via admin.settings.backup.create (fields: no payload fields)','2026-03-16 00:53:40');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `calibration_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calibration_data` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calibration_id` bigint(20) unsigned NOT NULL,
  `measurement_number` int(11) NOT NULL,
  `measurement_point` varchar(100) DEFAULT NULL,
  `nominal_value` decimal(15,6) DEFAULT NULL,
  `measured_value` decimal(15,6) DEFAULT NULL,
  `error` decimal(15,6) DEFAULT NULL,
  `unit` varchar(50) DEFAULT NULL,
  `uncertainty` decimal(15,6) DEFAULT NULL,
  `tolerance` decimal(15,6) DEFAULT NULL,
  `pass_fail` enum('pass','fail') DEFAULT NULL,
  `readings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'for multiple readings' CHECK (json_valid(`readings`)),
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calibration_data_calibration_id_index` (`calibration_id`),
  KEY `calibration_data_measurement_number_index` (`measurement_number`),
  CONSTRAINT `calibration_data_calibration_id_foreign` FOREIGN KEY (`calibration_id`) REFERENCES `calibrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calibration_data` WRITE;
/*!40000 ALTER TABLE `calibration_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `calibration_data` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `calibration_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calibration_reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calibration_id` bigint(20) unsigned NOT NULL,
  `report_number` varchar(50) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_size` int(11) DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT 1,
  `status` varchar(50) DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `verified_by` bigint(20) unsigned DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calibration_reports_report_number_unique` (`report_number`),
  KEY `calibration_reports_calibration_id_index` (`calibration_id`),
  KEY `calibration_reports_report_number_index` (`report_number`),
  CONSTRAINT `calibration_reports_calibration_id_foreign` FOREIGN KEY (`calibration_id`) REFERENCES `calibrations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calibration_reports` WRITE;
/*!40000 ALTER TABLE `calibration_reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `calibration_reports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `calibrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `calibrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calibration_number` varchar(50) NOT NULL,
  `job_order_item_id` bigint(20) unsigned NOT NULL,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `performed_by` bigint(20) unsigned NOT NULL COMMENT 'user_id',
  `calibration_date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `procedure_reference` varchar(255) DEFAULT NULL,
  `standards_used` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'array of standard IDs' CHECK (json_valid(`standards_used`)),
  `environmental_conditions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'temperature, humidity, pressure, conditions_acceptable' CHECK (json_valid(`environmental_conditions`)),
  `status` varchar(50) NOT NULL,
  `signatory_id` bigint(20) unsigned DEFAULT NULL,
  `signatory_remarks` text DEFAULT NULL COMMENT 'remarks from signatory during review',
  `reviewed_at` timestamp NULL DEFAULT NULL COMMENT 'when signatory reviewed the calibration',
  `certificate_id` bigint(20) unsigned DEFAULT NULL,
  `pass_fail` enum('pass','fail','conditional') DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `calibrations_calibration_number_unique` (`calibration_number`),
  KEY `calibrations_assignment_id_foreign` (`assignment_id`),
  KEY `calibrations_calibration_number_index` (`calibration_number`),
  KEY `calibrations_job_order_item_id_index` (`job_order_item_id`),
  KEY `calibrations_performed_by_index` (`performed_by`),
  KEY `calibrations_calibration_date_index` (`calibration_date`),
  KEY `calibrations_status_index` (`status`),
  KEY `calibrations_signatory_id_index` (`signatory_id`),
  KEY `calibrations_certificate_id_index` (`certificate_id`),
  CONSTRAINT `calibrations_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`),
  CONSTRAINT `calibrations_certificate_id_foreign` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`id`),
  CONSTRAINT `calibrations_job_order_item_id_foreign` FOREIGN KEY (`job_order_item_id`) REFERENCES `job_order_items` (`id`),
  CONSTRAINT `calibrations_signatory_id_foreign` FOREIGN KEY (`signatory_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calibrations` WRITE;
/*!40000 ALTER TABLE `calibrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `calibrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `certificate_releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificate_releases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `certificate_id` bigint(20) unsigned NOT NULL,
  `released_by` bigint(20) unsigned NOT NULL,
  `released_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `released_to` varchar(255) NOT NULL,
  `delivery_method` enum('pickup','courier','email','hand_delivery') NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `certificate_releases_certificate_id_index` (`certificate_id`),
  KEY `certificate_releases_released_by_index` (`released_by`),
  KEY `certificate_releases_released_at_index` (`released_at`),
  CONSTRAINT `certificate_releases_certificate_id_foreign` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `certificate_releases_released_by_foreign` FOREIGN KEY (`released_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `certificate_releases` WRITE;
/*!40000 ALTER TABLE `certificate_releases` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate_releases` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `certificate_revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificate_revisions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `certificate_id` bigint(20) unsigned NOT NULL,
  `version` int(11) NOT NULL,
  `revision_reason` text NOT NULL,
  `changes_made` text DEFAULT NULL,
  `previous_pdf_path` varchar(500) DEFAULT NULL,
  `revised_pdf_path` varchar(500) DEFAULT NULL,
  `revised_by` bigint(20) unsigned NOT NULL,
  `revised_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `certificate_revisions_certificate_id_index` (`certificate_id`),
  KEY `certificate_revisions_version_index` (`version`),
  CONSTRAINT `certificate_revisions_certificate_id_foreign` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `certificate_revisions` WRITE;
/*!40000 ALTER TABLE `certificate_revisions` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate_revisions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `certificate_verifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificate_verifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `certificate_id` bigint(20) unsigned NOT NULL,
  `certificate_number` varchar(50) NOT NULL,
  `verified_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `ip_address` varchar(50) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `verification_result` enum('valid','invalid','expired','revoked') DEFAULT NULL,
  `qr_scanned` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `certificate_verifications_certificate_id_index` (`certificate_id`),
  KEY `certificate_verifications_certificate_number_index` (`certificate_number`),
  KEY `certificate_verifications_verified_at_index` (`verified_at`),
  CONSTRAINT `certificate_verifications_certificate_id_foreign` FOREIGN KEY (`certificate_id`) REFERENCES `certificates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `certificate_verifications` WRITE;
/*!40000 ALTER TABLE `certificate_verifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `certificate_verifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `certificates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `certificates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `certificate_number` varchar(50) NOT NULL,
  `job_order_id` bigint(20) unsigned DEFAULT NULL,
  `job_order_item_id` bigint(20) unsigned DEFAULT NULL,
  `calibration_id` bigint(20) unsigned DEFAULT NULL,
  `issue_date` date NOT NULL,
  `expiry_date` date DEFAULT NULL,
  `valid_until` date DEFAULT NULL,
  `qr_code` varchar(255) DEFAULT NULL,
  `qr_code_path` varchar(255) DEFAULT NULL,
  `pdf_path` varchar(500) DEFAULT NULL,
  `pdf_hash` varchar(255) DEFAULT NULL COMMENT 'for integrity check',
  `template_used` varchar(100) DEFAULT NULL,
  `status` varchar(50) NOT NULL,
  `is_on_hold` tinyint(1) NOT NULL DEFAULT 0,
  `hold_reason` text DEFAULT NULL,
  `held_by` bigint(20) unsigned DEFAULT NULL,
  `held_at` timestamp NULL DEFAULT NULL,
  `version` int(11) NOT NULL DEFAULT 1,
  `revision_number` int(11) NOT NULL DEFAULT 0,
  `is_current` tinyint(1) NOT NULL DEFAULT 1,
  `issued_by` bigint(20) unsigned NOT NULL,
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `signed_by` bigint(20) unsigned DEFAULT NULL,
  `signed_at` timestamp NULL DEFAULT NULL COMMENT 'when certificate was digitally signed',
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT 'full certificate data snapshot for integrity' CHECK (json_valid(`data`)),
  `supersedes_certificate_id` bigint(20) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `generated_at` timestamp NULL DEFAULT NULL,
  `released_at` timestamp NULL DEFAULT NULL,
  `released_to` varchar(255) DEFAULT NULL,
  `released_by` bigint(20) unsigned DEFAULT NULL,
  `delivery_method` varchar(255) DEFAULT NULL,
  `release_notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `certificates_certificate_number_unique` (`certificate_number`),
  KEY `certificates_certificate_number_index` (`certificate_number`),
  KEY `certificates_job_order_item_id_index` (`job_order_item_id`),
  KEY `certificates_calibration_id_index` (`calibration_id`),
  KEY `certificates_status_index` (`status`),
  KEY `certificates_qr_code_index` (`qr_code`),
  KEY `certificates_job_order_id_foreign` (`job_order_id`),
  KEY `certificates_signed_by_index` (`signed_by`),
  KEY `certificates_held_by_foreign` (`held_by`),
  CONSTRAINT `certificates_calibration_id_foreign` FOREIGN KEY (`calibration_id`) REFERENCES `calibrations` (`id`),
  CONSTRAINT `certificates_held_by_foreign` FOREIGN KEY (`held_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `certificates_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`),
  CONSTRAINT `certificates_job_order_item_id_foreign` FOREIGN KEY (`job_order_item_id`) REFERENCES `job_order_items` (`id`),
  CONSTRAINT `certificates_signed_by_foreign` FOREIGN KEY (`signed_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `certificates` WRITE;
/*!40000 ALTER TABLE `certificates` DISABLE KEYS */;
INSERT INTO `certificates` VALUES (1,'CERT-2026-0001',NULL,NULL,NULL,'2026-02-06',NULL,'2027-02-06',NULL,NULL,NULL,NULL,'default','generated',0,NULL,NULL,NULL,1,0,1,4,NULL,4,NULL,NULL,NULL,NULL,'Customer: Ivan Dineros\nEquipment: asdasd\nService Type: electrical_calibration\n\nAdditional Notes:\nkajdklasldjals','2026-02-06 05:41:58',NULL,NULL,NULL,NULL,NULL,'2026-02-06 05:41:58','2026-02-06 05:41:58');
/*!40000 ALTER TABLE `certificates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `checklist_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checklist_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `description` text NOT NULL,
  `is_completed` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` bigint(20) unsigned NOT NULL,
  `completed_by` bigint(20) unsigned DEFAULT NULL,
  `completed_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `checklist_items_created_by_foreign` (`created_by`),
  KEY `checklist_items_job_order_id_is_completed_index` (`job_order_id`,`is_completed`),
  KEY `checklist_items_completed_by_foreign` (`completed_by`),
  CONSTRAINT `checklist_items_completed_by_foreign` FOREIGN KEY (`completed_by`) REFERENCES `users` (`id`),
  CONSTRAINT `checklist_items_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `checklist_items_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `checklist_items` WRITE;
/*!40000 ALTER TABLE `checklist_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `checklist_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customer_contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_contacts` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `position` varchar(100) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_contacts_customer_id_index` (`customer_id`),
  KEY `customer_contacts_is_primary_index` (`is_primary`),
  CONSTRAINT `customer_contacts_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_contacts` WRITE;
/*!40000 ALTER TABLE `customer_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customer_equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_equipment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned NOT NULL,
  `equipment_type` varchar(255) NOT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `id_number` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `specifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`specifications`)),
  `last_calibration` date DEFAULT NULL,
  `next_calibration` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_equipment_customer_id_index` (`customer_id`),
  KEY `customer_equipment_serial_number_index` (`serial_number`),
  CONSTRAINT `customer_equipment_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_equipment` WRITE;
/*!40000 ALTER TABLE `customer_equipment` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_equipment` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customer_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `jo_number` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) NOT NULL,
  `contact_no` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(500) NOT NULL,
  `equipment_description` text NOT NULL,
  `calibration_requirements` text NOT NULL,
  `required_date` date DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `pdf_filename` varchar(255) DEFAULT NULL,
  `pdf_path` varchar(255) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'draft',
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_requests_jo_number_unique` (`jo_number`),
  KEY `customer_requests_customer_id_foreign` (`customer_id`),
  KEY `customer_requests_created_by_foreign` (`created_by`),
  CONSTRAINT `customer_requests_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `customer_requests_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_requests` WRITE;
/*!40000 ALTER TABLE `customer_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `business_name` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `country` varchar(100) NOT NULL DEFAULT 'Philippines',
  `phone` varchar(50) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `industry_type` varchar(100) DEFAULT NULL,
  `tax_id` varchar(100) DEFAULT NULL,
  `credit_terms` int(11) NOT NULL DEFAULT 0 COMMENT 'in days',
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customers_code_unique` (`code`),
  KEY `customers_code_index` (`code`),
  KEY `customers_name_index` (`name`),
  KEY `customers_is_active_index` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'CUST000001','GEMARC',NULL,'asdasdasdas, asdasd, asdasda',NULL,NULL,NULL,'Philippines','alksdjalsk','asldkajsl@gmail.com',NULL,NULL,NULL,0,1,NULL,NULL,'2026-02-06 05:36:39','2026-02-06 05:36:39'),(2,'CUST000002','Redicon',NULL,'sdadaasd, asdasd, asdasdas',NULL,NULL,NULL,'Philippines','091023910293','redicon@gmail.com',NULL,NULL,NULL,0,1,NULL,NULL,'2026-02-06 06:01:36','2026-02-06 06:01:36'),(4,'CUST000003','CUSTOMER',NULL,NULL,NULL,NULL,NULL,'Philippines',NULL,'customer@gemarcph.com','CUSTOMER',NULL,NULL,0,1,NULL,NULL,'2026-02-10 23:41:46','2026-02-10 23:41:46');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `equipment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `equipment_code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `asset_number` varchar(100) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(10,2) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `responsible_person` bigint(20) unsigned DEFAULT NULL,
  `status` enum('available','in_use','maintenance','retired') DEFAULT NULL,
  `specifications` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`specifications`)),
  `calibration_required` tinyint(1) NOT NULL DEFAULT 0,
  `last_maintenance` date DEFAULT NULL,
  `next_maintenance` date DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `equipment_equipment_code_unique` (`equipment_code`),
  UNIQUE KEY `equipment_serial_number_unique` (`serial_number`),
  KEY `equipment_equipment_code_index` (`equipment_code`),
  KEY `equipment_serial_number_index` (`serial_number`),
  KEY `equipment_status_index` (`status`),
  KEY `equipment_category_index` (`category`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `equipment` WRITE;
/*!40000 ALTER TABLE `equipment` DISABLE KEYS */;
INSERT INTO `equipment` VALUES (1,'asdadas','asdasdas','calibration','asdasd','asdasd',NULL,NULL,NULL,NULL,'asdasd',NULL,'available',NULL,0,NULL,NULL,NULL,'2026-03-10 23:41:31','2026-03-10 23:41:31');
/*!40000 ALTER TABLE `equipment` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `equipment_maintenance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_maintenance` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `equipment_id` bigint(20) unsigned NOT NULL,
  `maintenance_type` enum('preventive','corrective','calibration','repair') DEFAULT NULL,
  `performed_by` bigint(20) unsigned DEFAULT NULL,
  `performed_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `description` text DEFAULT NULL,
  `parts_replaced` text DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `downtime_hours` int(11) DEFAULT NULL,
  `next_maintenance_date` date DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `equipment_maintenance_equipment_id_index` (`equipment_id`),
  KEY `equipment_maintenance_maintenance_type_index` (`maintenance_type`),
  KEY `equipment_maintenance_performed_at_index` (`performed_at`),
  CONSTRAINT `equipment_maintenance_equipment_id_foreign` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `equipment_maintenance` WRITE;
/*!40000 ALTER TABLE `equipment_maintenance` DISABLE KEYS */;
/*!40000 ALTER TABLE `equipment_maintenance` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `equipment_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipment_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `equipment_id` bigint(20) unsigned DEFAULT NULL,
  `equipment_name` varchar(255) NOT NULL,
  `requested_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `purpose` text NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `returned_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `job_order_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `equipment_requests_equipment_id_foreign` (`equipment_id`),
  KEY `equipment_requests_requested_by_foreign` (`requested_by`),
  KEY `equipment_requests_approved_by_foreign` (`approved_by`),
  KEY `equipment_requests_job_order_id_foreign` (`job_order_id`),
  CONSTRAINT `equipment_requests_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `equipment_requests_equipment_id_foreign` FOREIGN KEY (`equipment_id`) REFERENCES `equipment` (`id`) ON DELETE SET NULL,
  CONSTRAINT `equipment_requests_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `equipment_requests_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `equipment_requests` WRITE;
/*!40000 ALTER TABLE `equipment_requests` DISABLE KEYS */;
INSERT INTO `equipment_requests` VALUES (1,1,'asdasdas',3,4,'asdadadas','rejected','asdasdasdas','2026-03-10 23:47:28',NULL,'2026-03-10 23:45:03','2026-03-10 23:47:28',NULL),(2,1,'asdasdas',3,NULL,'qwqwewqeqwe','pending',NULL,NULL,NULL,'2026-03-11 07:34:33','2026-03-11 07:34:33',NULL);
/*!40000 ALTER TABLE `equipment_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `sku` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `unit` varchar(255) NOT NULL DEFAULT 'units',
  `min_level` int(11) NOT NULL DEFAULT 0,
  `status` enum('normal','low','out') NOT NULL DEFAULT 'normal',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_items_sku_unique` (`sku`),
  KEY `inventory_items_status_index` (`status`),
  KEY `inventory_items_category_index` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `inventory_requests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_requests` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `inventory_item_id` bigint(20) unsigned NOT NULL,
  `requested_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `purpose` text NOT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `admin_notes` text DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `job_order_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_requests_inventory_item_id_foreign` (`inventory_item_id`),
  KEY `inventory_requests_approved_by_foreign` (`approved_by`),
  KEY `inventory_requests_status_index` (`status`),
  KEY `inventory_requests_requested_by_index` (`requested_by`),
  KEY `inventory_requests_job_order_id_foreign` (`job_order_id`),
  CONSTRAINT `inventory_requests_approved_by_foreign` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_requests_inventory_item_id_foreign` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_requests_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE SET NULL,
  CONSTRAINT `inventory_requests_requested_by_foreign` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `inventory_requests` WRITE;
/*!40000 ALTER TABLE `inventory_requests` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_requests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoices` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(50) NOT NULL,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `issue_date` date NOT NULL,
  `due_date` date NOT NULL,
  `payment_terms` varchar(100) DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax_rate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL DEFAULT 0.00,
  `balance` decimal(10,2) DEFAULT NULL,
  `payment_status` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `invoices_invoice_number_unique` (`invoice_number`),
  KEY `invoices_invoice_number_index` (`invoice_number`),
  KEY `invoices_job_order_id_index` (`job_order_id`),
  KEY `invoices_customer_id_index` (`customer_id`),
  KEY `invoices_payment_status_index` (`payment_status`),
  KEY `invoices_due_date_index` (`due_date`),
  CONSTRAINT `invoices_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `invoices_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoices` WRITE;
/*!40000 ALTER TABLE `invoices` DISABLE KEYS */;
/*!40000 ALTER TABLE `invoices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_order_attachments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_order_attachments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `uploaded_by` bigint(20) unsigned NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_order_attachments_job_order_id_index` (`job_order_id`),
  CONSTRAINT `job_order_attachments_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_order_attachments` WRITE;
/*!40000 ALTER TABLE `job_order_attachments` DISABLE KEYS */;
INSERT INTO `job_order_attachments` VALUES (9,12,'NOV CDB 2025.xlsx','job-attachments/12/C87cW6Xgfpb5jftQ1n5Wsqm9ythqjHQVlL0tTxfr.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',480818,NULL,4,'2026-03-10 07:02:56','2026-03-10 07:02:56','2026-03-10 07:02:56'),(10,12,'3.jpg','job-attachments/12/JpIx6kePfDNCVmEvYkucTYoJEBZuaSd8uSqu6Gkm.jpg','image/jpeg',470113,NULL,4,'2026-03-10 07:03:07','2026-03-10 07:03:07','2026-03-10 07:03:07'),(15,10,'3.jpg','job-attachments/10/bXOMzt2aBBdwB3qvIzYWuHsNKJnjGsuGnYk6a6br.jpg','image/jpeg',470113,NULL,3,'2026-03-13 00:49:05','2026-03-13 00:49:05','2026-03-13 00:49:05');
/*!40000 ALTER TABLE `job_order_attachments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_order_crew_members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_order_crew_members` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `added_by` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_order_crew_members_job_order_id_user_id_unique` (`job_order_id`,`user_id`),
  KEY `job_order_crew_members_user_id_foreign` (`user_id`),
  KEY `job_order_crew_members_added_by_foreign` (`added_by`),
  KEY `job_order_crew_members_job_order_id_index` (`job_order_id`),
  KEY `job_order_crew_members_name_index` (`name`),
  CONSTRAINT `job_order_crew_members_added_by_foreign` FOREIGN KEY (`added_by`) REFERENCES `users` (`id`),
  CONSTRAINT `job_order_crew_members_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `job_order_crew_members_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_order_crew_members` WRITE;
/*!40000 ALTER TABLE `job_order_crew_members` DISABLE KEYS */;
INSERT INTO `job_order_crew_members` VALUES (3,1,3,NULL,3,'2026-02-09 01:22:25','2026-02-09 01:22:25'),(5,12,3,NULL,3,'2026-03-03 01:06:26','2026-03-03 01:06:26'),(8,10,3,NULL,3,'2026-03-13 00:41:38','2026-03-13 00:41:38');
/*!40000 ALTER TABLE `job_order_crew_members` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `item_number` int(11) NOT NULL,
  `equipment_type` varchar(255) NOT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `id_number` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `resolution` varchar(100) DEFAULT NULL,
  `accuracy` varchar(100) DEFAULT NULL,
  `calibration_type` varchar(100) DEFAULT NULL COMMENT 'On-site/In-house',
  `calibration_points` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `total_price` decimal(10,2) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_order_items_job_order_id_index` (`job_order_id`),
  KEY `job_order_items_serial_number_index` (`serial_number`),
  CONSTRAINT `job_order_items_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_order_items` WRITE;
/*!40000 ALTER TABLE `job_order_items` DISABLE KEYS */;
INSERT INTO `job_order_items` VALUES (1,11,1,'Pressure Gauge',NULL,'PG-200','WEB-SN-01',NULL,'200 bar',NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2026-03-02 01:02:48','2026-03-02 01:02:48'),(2,12,1,'Pressure Gauge',NULL,'PG-200','WEB-SN-01',NULL,'200 bar',NULL,NULL,NULL,NULL,2,NULL,NULL,NULL,'2026-03-02 01:03:02','2026-03-02 01:03:02'),(3,16,1,'asdasdasd',NULL,'asdasdasd','asdasdsa',NULL,'asdasdas',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-03-10 07:53:46','2026-03-10 07:53:46'),(4,17,1,'23231231',NULL,'12312','12312',NULL,'12312',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-03-10 07:59:29','2026-03-10 07:59:29'),(5,17,2,'123123',NULL,'123123','123213',NULL,'12312',NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-03-10 07:59:29','2026-03-10 07:59:29'),(6,18,1,'23231231',NULL,'12312',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-03-10 08:01:30','2026-03-10 08:01:30');
/*!40000 ALTER TABLE `job_order_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_order_statuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_order_statuses` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `status` varchar(50) NOT NULL,
  `previous_status` varchar(50) DEFAULT NULL,
  `changed_by` bigint(20) unsigned NOT NULL,
  `changed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `remarks` text DEFAULT NULL,
  `metadata` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`metadata`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_order_statuses_job_order_id_index` (`job_order_id`),
  KEY `job_order_statuses_status_index` (`status`),
  KEY `job_order_statuses_changed_at_index` (`changed_at`),
  CONSTRAINT `job_order_statuses_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_order_statuses` WRITE;
/*!40000 ALTER TABLE `job_order_statuses` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_order_statuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_number` varchar(50) NOT NULL,
  `customer_id` bigint(20) unsigned NOT NULL,
  `service_type` varchar(255) DEFAULT NULL,
  `service_description` text DEFAULT NULL,
  `expected_start_date` date DEFAULT NULL,
  `expected_completion_date` date DEFAULT NULL,
  `service_address` text DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `province` varchar(255) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `requested_by` varchar(255) DEFAULT NULL,
  `client_po_ctrl_no` varchar(255) DEFAULT NULL,
  `terms` text DEFAULT NULL,
  `service_invoice_number` varchar(255) DEFAULT NULL,
  `other_details` varchar(255) DEFAULT NULL,
  `request_date` date NOT NULL,
  `required_date` date DEFAULT NULL,
  `priority` enum('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
  `status` varchar(50) NOT NULL,
  `total_items` int(11) NOT NULL DEFAULT 0,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `discount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `tax_amount` decimal(10,2) NOT NULL DEFAULT 0.00,
  `grand_total` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `special_instructions` text DEFAULT NULL,
  `created_by` bigint(20) unsigned NOT NULL,
  `approved_by` bigint(20) unsigned DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `approval_signature` text DEFAULT NULL,
  `approval_comments` text DEFAULT NULL,
  `rejected_by` bigint(20) unsigned DEFAULT NULL,
  `rejected_at` timestamp NULL DEFAULT NULL,
  `rejection_reason` text DEFAULT NULL,
  `pdf_filename` varchar(255) DEFAULT NULL,
  `pdf_path` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `job_orders_job_order_number_unique` (`job_order_number`),
  KEY `job_orders_job_order_number_index` (`job_order_number`),
  KEY `job_orders_customer_id_index` (`customer_id`),
  KEY `job_orders_status_index` (`status`),
  KEY `job_orders_priority_index` (`priority`),
  KEY `job_orders_required_date_index` (`required_date`),
  KEY `job_orders_created_at_index` (`created_at`),
  CONSTRAINT `job_orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_orders` WRITE;
/*!40000 ALTER TABLE `job_orders` DISABLE KEYS */;
INSERT INTO `job_orders` VALUES (1,'JO-00001',1,'Installation Service','asdadasdas','2026-02-06','2026-02-12','asdasdasdas','asdasd','asdasda','asdas','asjdlasjd',NULL,NULL,NULL,NULL,'2026-02-06','2026-02-12','normal','in_progress',0,NULL,0.00,0.00,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-06 05:36:39','2026-02-06 06:04:09',NULL),(2,'JO-00002',2,'Generator Maintenance','laaklakklalkaklalk',NULL,NULL,'sdadaasd','asdasd','asdasdas','1685','kasd',NULL,NULL,NULL,NULL,'2026-02-06',NULL,'normal','pending',0,NULL,0.00,0.00,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'job-order-JO-00002-2026-03-10-135849.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/job-order-JO-00002-2026-03-10-135849.pdf','2026-02-06 06:01:37','2026-03-10 05:58:50',NULL),(3,'JO-00003',4,'Repair','aasdlkihasdflkjslakdjflkasdjflksjadflkjsadflkjsdf',NULL,'2026-02-19','marikina','marikina','calabarzon','1860','asdadasdasdasdas',NULL,NULL,NULL,NULL,'2026-02-18','2026-02-19','normal','cancelled',0,NULL,0.00,0.00,NULL,'asasdasadsads\n\nCompany: Gemarc Enterprises Inc\nContact: 09776172809\nInvoice: ',NULL,7,NULL,NULL,NULL,NULL,7,'2026-02-18 01:53:13','Cancelled by customer',NULL,NULL,'2026-02-18 01:03:42','2026-02-18 01:53:13',NULL),(4,'JO-00004',4,'Inspection','asdasdadas',NULL,'2026-02-18','654654654654654','654',NULL,NULL,'IT HelpDesk',NULL,NULL,NULL,NULL,'2026-02-18','2026-02-18','normal','cancelled',0,NULL,0.00,0.00,NULL,'asdasdsa\n\nCompany: 32435y6uyiuytgrfeaddfdgh\nContact: 10069410610\nInvoice: ',NULL,7,NULL,NULL,NULL,NULL,7,'2026-02-18 02:26:37','Cancelled by customer',NULL,NULL,'2026-02-18 02:00:07','2026-02-18 02:26:37',NULL),(5,'JO-00005',4,'Calibration','asdadasdas',NULL,'2026-02-19','asdasdasdas','654','asdasda','1685','CUSTOMER',NULL,NULL,NULL,NULL,'2026-02-18','2026-02-19','normal','cancelled',0,NULL,0.00,0.00,NULL,'asdasdasdas',NULL,7,NULL,NULL,NULL,NULL,7,'2026-03-01 23:25:22','Cancelled by customer','job-order-form-JO-00005-2026-03-02-080937.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generatedjob-order-form-JO-00005-2026-03-02-080937.pdf','2026-02-18 02:47:37','2026-03-02 00:09:37',NULL),(6,'JO-00006',4,'Calibration','aaasasdasdasd',NULL,'2026-02-18','654654654654654','654','asd','asd','CUSTOMER',NULL,NULL,NULL,NULL,'2026-02-18','2026-02-18','high','cancelled',0,NULL,0.00,0.00,NULL,'asdasdasdas',NULL,7,NULL,NULL,NULL,NULL,7,'2026-03-01 23:25:30','Cancelled by customer',NULL,NULL,'2026-02-18 04:35:57','2026-03-01 23:25:30',NULL),(7,'JO-00007',4,'Maintenance','asdasdasdasdasd',NULL,'2026-02-18','654654654654654','654','calabarzon','1860','CUSTOMER',NULL,NULL,NULL,NULL,'2026-02-18','2026-02-18','normal','cancelled',0,NULL,0.00,0.00,NULL,'dasdassdasdaasdasd',NULL,7,NULL,NULL,NULL,NULL,7,'2026-03-01 23:25:34','Cancelled by customer','form-JO-00007-2026-02-18-153358.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/form-JO-00007-2026-02-18-153358.pdf','2026-02-18 04:44:20','2026-03-01 23:25:34',NULL),(8,'JO-00008',4,'Repair','[;kjiojoipjoip',NULL,'2026-02-23','654654654654654','654','calabarzon','1860','CUSTOMER',NULL,NULL,NULL,NULL,'2026-02-23','2026-02-23','high','cancelled',0,NULL,0.00,0.00,NULL,'olhjiiopujhopijopijop',NULL,7,NULL,NULL,NULL,NULL,7,'2026-03-01 23:25:39','Cancelled by customer','job-order-form-JO-00008-2026-03-02-083624.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generatedjob-order-form-JO-00008-2026-03-02-083624.pdf','2026-02-23 00:44:49','2026-03-02 00:36:24',NULL),(9,'JO-2026-01231231',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-02-24',NULL,'normal','pending',0,NULL,0.00,0.00,NULL,NULL,NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'job-order-JO-2026-01231231-2026-03-10-113550.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/job-order-JO-2026-01231231-2026-03-10-113550.pdf','2026-02-24 01:50:43','2026-03-10 03:35:50',NULL),(10,'JO-2026-00000',1,'Calibration','TESTING CALIBRATION',NULL,'2026-03-02','MARIKINA','MARIKI','CALABARZONM','1860','GEMARC','98797987','COD','987987987',NULL,'2026-02-24','2026-03-02','normal','assigned',0,NULL,0.00,0.00,NULL,'ASAP',NULL,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'job-order-JO-2026-00000-2026-03-10-113557.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/job-order-JO-2026-00000-2026-03-10-113557.pdf','2026-02-24 01:52:43','2026-03-10 08:45:53',NULL),(11,'JO-WEBTEST-090247',1,'Repair, Calibration','WEB remarks',NULL,NULL,'WEBTEST Site',NULL,NULL,NULL,'WEBTEST Contact','PO-WEB-001','WEB terms','SI-WEB-001','WEB others','2026-03-02',NULL,'normal','for_accounting_approval',0,NULL,0.00,0.00,NULL,'WEB remarks','{\"marketing_pdf_overrides\":{\"company_name\":\"WEBTEST COMPANY\",\"company_tin\":\"999-888-777\",\"address\":\"WEBTEST Address\",\"contact_no\":\"09179999999\"}}',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'job-order-form-JO-WEBTEST-090247-2026-03-02-091131.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generatedjob-order-form-JO-WEBTEST-090247-2026-03-02-091131.pdf','2026-03-02 01:02:48','2026-03-02 01:11:31',NULL),(12,'JO-WEBTEST-090301',1,'Repair, Calibration','WEB remarks',NULL,NULL,'WEBTEST Site',NULL,NULL,NULL,'WEBTEST Contact','PO-WEB-001','WEB terms','SI-WEB-001','WEB others','2026-03-02',NULL,'normal','assigned',0,NULL,0.00,0.00,NULL,'WEB remarks','{\"marketing_pdf_overrides\":{\"company_name\":\"WEBTEST COMPANY\",\"company_tin\":\"999-888-777\",\"address\":\"WEBTEST Address\",\"contact_no\":\"09179999999\"}}',2,14,'2026-03-02 03:37:53',NULL,NULL,NULL,NULL,NULL,'job-order-form-JO-WEBTEST-090301-2026-03-02-102720.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generatedjob-order-form-JO-WEBTEST-090301-2026-03-02-102720.pdf','2026-03-02 01:03:02','2026-03-02 03:38:26',NULL),(15,'JO-00013',4,'Maintenance','asdasdasdas',NULL,'2026-03-10','asdasdas','asdasdsa','asdasdsa','asdasd','CUSTOMER',NULL,NULL,NULL,NULL,'2026-03-10','2026-03-10','normal','cancelled',0,NULL,0.00,0.00,NULL,'asdadasdasdsa',NULL,7,NULL,NULL,NULL,NULL,7,'2026-03-10 08:01:06','Cancelled by customer','job-order-JO-00013-2026-03-10-151444.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/job-order-JO-00013-2026-03-10-151444.pdf','2026-03-10 07:14:44','2026-03-10 08:01:06',NULL),(16,'JO-00016',4,'Calibration','asdadasd',NULL,'2026-03-10','654654654654654','654','asdasd','adasdsa','CUSTOMER',NULL,NULL,NULL,NULL,'2026-03-10','2026-03-10','normal','cancelled',0,NULL,0.00,0.00,NULL,'adasdas',NULL,7,NULL,NULL,NULL,NULL,7,'2026-03-10 08:01:04','Cancelled by customer','job-order-JO-00016-2026-03-10-155346.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/job-order-JO-00016-2026-03-10-155346.pdf','2026-03-10 07:22:13','2026-03-10 08:01:04',NULL),(17,'JO-00017',4,'Repair','asdasdsa',NULL,'2026-03-12','asdasdsa','asdasd','asdasd','asdasd','CUSTOMER',NULL,NULL,NULL,NULL,'2026-03-10','2026-03-12','normal','cancelled',0,NULL,0.00,0.00,NULL,'asdasdasdsa',NULL,7,NULL,NULL,NULL,NULL,7,'2026-03-10 08:01:01','Cancelled by customer','job-order-JO-00017-2026-03-10-155929.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/job-order-JO-00017-2026-03-10-155929.pdf','2026-03-10 07:59:29','2026-03-10 08:01:01',NULL),(18,'JO-00018',4,'Maintenance','asdasdsadsadsa',NULL,'2026-03-10','asdasd','asdasd','asdas','asdsad','CUSTOMER',NULL,NULL,NULL,NULL,'2026-03-10','2026-03-10','normal','pending',0,NULL,0.00,0.00,NULL,'asdasd',NULL,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'job-order-JO-00018-2026-03-10-160325.pdf','D:GitHub	echnical-management-system	echnical-management-systemstorageapp/public/generated/job-order-JO-00018-2026-03-10-160325.pdf','2026-03-10 08:01:30','2026-03-10 08:03:25',NULL);
/*!40000 ALTER TABLE `job_orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `measurement_points`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `measurement_points` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calibration_id` bigint(20) unsigned NOT NULL,
  `point_number` int(11) NOT NULL,
  `reference_value` decimal(15,6) NOT NULL,
  `uut_reading` decimal(15,6) NOT NULL,
  `error` decimal(15,6) DEFAULT NULL,
  `uncertainty` decimal(15,6) DEFAULT NULL,
  `acceptance_criteria` varchar(255) DEFAULT NULL,
  `status` enum('pass','fail') DEFAULT NULL,
  `readings_ascending` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`readings_ascending`)),
  `readings_descending` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`readings_descending`)),
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `measurement_points_calibration_id_index` (`calibration_id`),
  CONSTRAINT `measurement_points_calibration_id_foreign` FOREIGN KEY (`calibration_id`) REFERENCES `calibrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `measurement_points` WRITE;
/*!40000 ALTER TABLE `measurement_points` DISABLE KEYS */;
/*!40000 ALTER TABLE `measurement_points` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_01_12_033035_create_roles_table',1),(5,'2026_01_12_033042_add_role_to_users_table',1),(6,'2026_01_12_033043_01_create_customers_table',1),(7,'2026_01_12_033043_02_create_customer_contacts_table',1),(8,'2026_01_12_033043_03_create_customer_equipment_table',1),(9,'2026_01_12_033053_create_job_orders_table',1),(10,'2026_01_12_033054_02_create_job_order_items_table',1),(11,'2026_01_12_033054_03_create_job_order_statuses_table',1),(12,'2026_01_12_033054_04_create_job_order_attachments_table',1),(13,'2026_01_12_033103_create_assignments_table',1),(14,'2026_01_12_033103_create_schedules_table',1),(15,'2026_01_12_033103_create_workload_allocations_table',1),(16,'2026_01_12_033111_create_calibrations_table',1),(17,'2026_01_12_033112_create_calibration_data_table',1),(18,'2026_01_12_033112_create_calibration_reports_table',1),(19,'2026_01_12_033112_create_measurement_points_table',1),(20,'2026_01_12_033112_create_uncertainty_calculations_table',1),(21,'2026_01_12_033120_create_approval_histories_table',1),(22,'2026_01_12_033120_create_signatory_approvals_table',1),(23,'2026_01_12_033120_create_technical_reviews_table',1),(24,'2026_01_12_033126_01_create_certificates_table',1),(25,'2026_01_12_033126_02_create_certificate_revisions_table',1),(26,'2026_01_12_033126_03_create_certificate_verifications_table',1),(27,'2026_01_12_033133_01_create_releases_table',1),(28,'2026_01_12_033133_02_create_accounting_releases_table',1),(29,'2026_01_12_033133_03_create_invoices_table',1),(30,'2026_01_12_033139_01_create_equipment_table',1),(31,'2026_01_12_033139_02_create_standards_table',1),(32,'2026_01_12_033140_01_create_standard_calibrations_table',1),(33,'2026_01_12_033140_02_create_equipment_maintenance_table',1),(34,'2026_01_12_033140_03_create_audit_logs_table',1),(35,'2026_01_14_031812_add_service_fields_to_job_orders_table',1),(36,'2026_01_19_054744_create_reports_table',1),(37,'2026_01_20_060734_add_certificate_tracking_fields_to_certificates_table',1),(38,'2026_01_20_060808_add_approval_fields_to_job_orders_table',1),(39,'2026_01_20_063311_make_certificate_item_and_calibration_nullable',1),(40,'2026_01_20_090000_add_availability_skills_to_users_table',1),(41,'2026_01_21_000000_add_signatory_fields_to_calibrations_and_certificates',1),(42,'2026_01_22_000001_create_payments_table',1),(43,'2026_01_22_000002_create_certificate_releases_table',1),(44,'2026_01_22_000003_add_hold_fields_to_certificates_table',1),(45,'2026_02_03_000000_create_inventory_items_table',1),(46,'2026_02_03_100000_create_inventory_requests_table',1),(47,'2026_02_09_083040_create_checklist_items_table',2),(48,'2026_02_09_084045_add_completed_by_fk_to_checklist_items_table',3),(49,'2026_02_09_090517_create_job_order_crew_members_table',4),(50,'2026_02_11_000001_add_customer_id_to_users_table',5),(51,'2026_02_18_103708_create_customer_requests_table',6),(52,'2026_02_18_105257_add_pdf_fields_to_job_orders_table',7),(53,'2026_02_18_add_pdf_fields_to_job_orders_table',8),(54,'2026_03_02_080500_add_marketing_pdf_fields_to_job_orders_table',9),(55,'2026_03_11_000001_create_equipment_requests_table',10),(56,'2026_03_11_000002_add_job_order_id_to_requests_tables',11);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `payment_code` varchar(255) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `paid_at` timestamp NULL DEFAULT NULL,
  `status` enum('pending','paid','verified','refunded') NOT NULL DEFAULT 'pending',
  `verified_by` bigint(20) unsigned DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `payments_payment_code_unique` (`payment_code`),
  KEY `payments_verified_by_foreign` (`verified_by`),
  KEY `payments_job_order_id_index` (`job_order_id`),
  KEY `payments_status_index` (`status`),
  KEY `payments_verified_at_index` (`verified_at`),
  CONSTRAINT `payments_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_verified_by_foreign` FOREIGN KEY (`verified_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `releases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `releases` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `release_number` varchar(50) NOT NULL,
  `job_order_id` bigint(20) unsigned NOT NULL,
  `released_by` bigint(20) unsigned NOT NULL,
  `released_to` varchar(255) NOT NULL,
  `release_date` date NOT NULL,
  `release_time` time DEFAULT NULL,
  `delivery_method` enum('pickup','courier','email','hand_carry') DEFAULT NULL,
  `tracking_number` varchar(255) DEFAULT NULL,
  `recipient_name` varchar(255) DEFAULT NULL,
  `recipient_signature` varchar(255) DEFAULT NULL COMMENT 'signature path',
  `status` varchar(50) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `releases_release_number_unique` (`release_number`),
  KEY `releases_release_number_index` (`release_number`),
  KEY `releases_job_order_id_index` (`job_order_id`),
  KEY `releases_release_date_index` (`release_date`),
  KEY `releases_status_index` (`status`),
  CONSTRAINT `releases_job_order_id_foreign` FOREIGN KEY (`job_order_id`) REFERENCES `job_orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `releases` WRITE;
/*!40000 ALTER TABLE `releases` DISABLE KEYS */;
/*!40000 ALTER TABLE `releases` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reports` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `submitted_by` bigint(20) unsigned NOT NULL,
  `work_summary` text NOT NULL,
  `parts_used` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `photos` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`photos`)),
  `signature` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `reviewed_by` bigint(20) unsigned DEFAULT NULL,
  `reviewed_at` timestamp NULL DEFAULT NULL,
  `review_notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reports_reviewed_by_foreign` (`reviewed_by`),
  KEY `reports_assignment_id_index` (`assignment_id`),
  KEY `reports_submitted_by_index` (`submitted_by`),
  KEY `reports_status_index` (`status`),
  CONSTRAINT `reports_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reports_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reports_submitted_by_foreign` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reports` WRITE;
/*!40000 ALTER TABLE `reports` DISABLE KEYS */;
/*!40000 ALTER TABLE `reports` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_slug_unique` (`slug`),
  KEY `roles_slug_index` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Administrator','admin','Full system access and management','[\"manage_users\",\"manage_roles\",\"manage_job_orders\",\"view_all_reports\",\"system_settings\",\"approve_requests\",\"manage_inventory\"]',1,'2026-03-02 02:33:18','2026-03-02 02:33:18'),(2,'Marketing','marketing','Create and manage customer requests and job orders','[\"create_job_orders\",\"view_own_job_orders\",\"edit_own_job_orders\",\"view_customers\"]',1,'2026-03-02 02:33:18','2026-03-02 02:33:18'),(3,'Technical Personnel','tech_personnel','Execute assigned technical tasks and maintenance','[\"view_assigned_jobs\",\"update_job_status\",\"submit_reports\",\"log_activities\",\"view_equipment\"]',1,'2026-03-02 02:33:18','2026-03-02 02:33:18'),(4,'Technical Head','tech_head','Supervise technical team and assign tasks','[\"view_all_jobs\",\"assign_technicians\",\"review_reports\",\"approve_technical_work\",\"manage_schedules\",\"view_team_performance\"]',1,'2026-03-02 02:33:18','2026-03-02 02:33:18'),(5,'Signatory','signatory','Review and approve job orders and reports','[\"view_pending_approvals\",\"approve_job_orders\",\"reject_job_orders\",\"view_all_reports\",\"add_comments\"]',1,'2026-03-02 02:33:18','2026-03-02 02:33:18'),(14,'Customer','customer','View own job requests and certificates','[\"view_job_orders\",\"view_certificates\"]',1,'2026-03-02 02:33:18','2026-03-02 02:33:18'),(15,'Accounting','accounting','Review and approve job orders for accounting clearance','[\"view_pending_approvals\",\"approve_job_orders\",\"reject_job_orders\",\"view_all_jobs\",\"view_accounting_dashboard\"]',1,'2026-03-02 02:33:18','2026-03-02 02:33:18');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `assignment_id` bigint(20) unsigned NOT NULL,
  `technician_id` bigint(20) unsigned NOT NULL,
  `scheduled_start` datetime NOT NULL,
  `scheduled_end` datetime NOT NULL,
  `actual_start` datetime DEFAULT NULL,
  `actual_end` datetime DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_assignment_id_index` (`assignment_id`),
  KEY `schedules_technician_id_index` (`technician_id`),
  KEY `schedules_scheduled_start_index` (`scheduled_start`),
  CONSTRAINT `schedules_assignment_id_foreign` FOREIGN KEY (`assignment_id`) REFERENCES `assignments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('0vqm5cPQXEi0jGKdXdJGuJnNxUDNFS2Am6jMUkr1',1,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.0.0 Safari/537.36','YTo1OntzOjY6Il90b2tlbiI7czo0MDoiSkZXWlgzeVVBNGJjMXhpVXk0MUVESTNEWFRya3JPUE5uWnJHeFdlVSI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjI6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYWRtaW4vc2V0dGluZ3MiO3M6NToicm91dGUiO3M6MjA6ImFkbWluLnNldHRpbmdzLmluZGV4Ijt9czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTt9',1773622420),('D16ysPs90PaLDyi0ofQ5wkgIgnTxWZHpnqFfkENl',NULL,NULL,'','YTozOntzOjY6Il90b2tlbiI7czo0MDoiVUdSVU5vOE1FcDdQbzA5NGdlTm1WUFc5UE9za0ZCTXFYMTBWTFdFUSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODoiaHR0cDovLzoiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1773619463),('FtWAUPqIsTDgJW1iXxkLN7xvcEGBpig6Nldgsaxg',NULL,NULL,'','YTozOntzOjY6Il90b2tlbiI7czo0MDoiZzNYOThOWHRVSVZ2RWpmczlLTWRmTzJwdE0yaTV5ekoxaWt6RWw5aiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODoiaHR0cDovLzoiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1773619488),('kgMexn3wgijGfazHuIo8fC9R6wFPMTab4A0PKBRo',NULL,NULL,'','YTozOntzOjY6Il90b2tlbiI7czo0MDoiQTY1REdGc0pMQlpNRldENE1EaWlOcjY1TDNRWDhRU2NBNFNrdk5FYSI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODoiaHR0cDovLzoiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1773619536),('SuRQwaD5h935F9Yw6l83T4BmQZ5VLnBYQyWrvkAS',NULL,NULL,'','YTozOntzOjY6Il90b2tlbiI7czo0MDoiRVBwa3V6dWVCZ05OVzN2OGtOTFd6OTJLNlFQbnJtOXdPSDNQZEM1ZiI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODoiaHR0cDovLzoiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1773619456),('Ylop53q3xvp195YaQlwMZzZfRIQcFaWuDFn4k7hr',NULL,NULL,'','YTozOntzOjY6Il90b2tlbiI7czo0MDoiUDhzenVLd0pmbVJXMkhDak9wY0hSWWd0ZG9IWEFKQ0JVOTh5eFZ4ViI7czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6ODoiaHR0cDovLzoiO3M6NToicm91dGUiO047fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fX0=',1773619516);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `signatory_approvals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `signatory_approvals` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calibration_id` bigint(20) unsigned NOT NULL,
  `signatory_id` bigint(20) unsigned NOT NULL COMMENT 'user_id',
  `approval_level` enum('reviewer','approver') NOT NULL,
  `approval_order` int(11) NOT NULL DEFAULT 1,
  `approved_at` timestamp NULL DEFAULT NULL,
  `signature_path` varchar(255) DEFAULT NULL,
  `signature_data` text DEFAULT NULL COMMENT 'base64 encoded signature',
  `comments` text DEFAULT NULL,
  `status` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `signatory_approvals_calibration_id_index` (`calibration_id`),
  KEY `signatory_approvals_signatory_id_index` (`signatory_id`),
  KEY `signatory_approvals_status_index` (`status`),
  KEY `signatory_approvals_approval_level_index` (`approval_level`),
  CONSTRAINT `signatory_approvals_calibration_id_foreign` FOREIGN KEY (`calibration_id`) REFERENCES `calibrations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `signatory_approvals` WRITE;
/*!40000 ALTER TABLE `signatory_approvals` DISABLE KEYS */;
/*!40000 ALTER TABLE `signatory_approvals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `standard_calibrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standard_calibrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `standard_id` bigint(20) unsigned NOT NULL,
  `calibration_date` date NOT NULL,
  `certificate_number` varchar(255) NOT NULL,
  `performed_by` varchar(255) DEFAULT NULL COMMENT 'External lab name',
  `next_due_date` date NOT NULL,
  `certificate_path` varchar(500) DEFAULT NULL,
  `measurement_results` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`measurement_results`)),
  `traceability` text DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `standard_calibrations_standard_id_index` (`standard_id`),
  KEY `standard_calibrations_calibration_date_index` (`calibration_date`),
  KEY `standard_calibrations_next_due_date_index` (`next_due_date`),
  CONSTRAINT `standard_calibrations_standard_id_foreign` FOREIGN KEY (`standard_id`) REFERENCES `standards` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `standard_calibrations` WRITE;
/*!40000 ALTER TABLE `standard_calibrations` DISABLE KEYS */;
/*!40000 ALTER TABLE `standard_calibrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `standards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `standards` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `standard_code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(100) DEFAULT NULL COMMENT 'Master/Working/Check',
  `manufacturer` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `serial_number` varchar(255) DEFAULT NULL,
  `range` varchar(255) DEFAULT NULL,
  `accuracy` varchar(255) DEFAULT NULL,
  `resolution` varchar(100) DEFAULT NULL,
  `certificate_number` varchar(255) DEFAULT NULL,
  `calibration_date` date DEFAULT NULL,
  `next_calibration_date` date NOT NULL,
  `calibration_interval` int(11) NOT NULL DEFAULT 12 COMMENT 'months',
  `traceability` text DEFAULT NULL COMMENT 'NIST, PTB, etc.',
  `location` varchar(255) DEFAULT NULL,
  `status` enum('valid','due','overdue','retired') DEFAULT NULL,
  `usage_count` int(11) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `alert_days_before` int(11) NOT NULL DEFAULT 30,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `standards_standard_code_unique` (`standard_code`),
  UNIQUE KEY `standards_serial_number_unique` (`serial_number`),
  KEY `standards_standard_code_index` (`standard_code`),
  KEY `standards_serial_number_index` (`serial_number`),
  KEY `standards_next_calibration_date_index` (`next_calibration_date`),
  KEY `standards_status_index` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `standards` WRITE;
/*!40000 ALTER TABLE `standards` DISABLE KEYS */;
/*!40000 ALTER TABLE `standards` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `technical_reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `technical_reviews` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calibration_id` bigint(20) unsigned NOT NULL,
  `reviewer_id` bigint(20) unsigned NOT NULL COMMENT 'user_id',
  `review_date` date NOT NULL,
  `review_time` time DEFAULT NULL,
  `result` enum('approved','rejected','conditional') DEFAULT NULL,
  `findings` text DEFAULT NULL,
  `recommendations` text DEFAULT NULL,
  `data_reviewed` tinyint(1) NOT NULL DEFAULT 0,
  `calculations_verified` tinyint(1) NOT NULL DEFAULT 0,
  `standards_checked` tinyint(1) NOT NULL DEFAULT 0,
  `status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `technical_reviews_calibration_id_index` (`calibration_id`),
  KEY `technical_reviews_reviewer_id_index` (`reviewer_id`),
  KEY `technical_reviews_result_index` (`result`),
  CONSTRAINT `technical_reviews_calibration_id_foreign` FOREIGN KEY (`calibration_id`) REFERENCES `calibrations` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `technical_reviews` WRITE;
/*!40000 ALTER TABLE `technical_reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `technical_reviews` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `uncertainty_calculations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `uncertainty_calculations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `calibration_id` bigint(20) unsigned NOT NULL,
  `component` varchar(255) NOT NULL COMMENT 'e.g., standard, resolution, repeatability',
  `value` decimal(15,8) NOT NULL,
  `distribution` varchar(50) DEFAULT NULL COMMENT 'normal, rectangular, triangular',
  `divisor` decimal(5,2) DEFAULT NULL,
  `standard_uncertainty` decimal(15,8) DEFAULT NULL,
  `sensitivity_coefficient` decimal(10,4) DEFAULT NULL,
  `uncertainty_contribution` decimal(15,8) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uncertainty_calculations_calibration_id_index` (`calibration_id`),
  CONSTRAINT `uncertainty_calculations_calibration_id_foreign` FOREIGN KEY (`calibration_id`) REFERENCES `calibrations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `uncertainty_calculations` WRITE;
/*!40000 ALTER TABLE `uncertainty_calculations` DISABLE KEYS */;
/*!40000 ALTER TABLE `uncertainty_calculations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  `customer_id` bigint(20) unsigned DEFAULT NULL,
  `department` varchar(100) DEFAULT NULL,
  `employee_id` varchar(50) DEFAULT NULL,
  `signature_path` varchar(255) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `last_login_at` timestamp NULL DEFAULT NULL,
  `availability` varchar(30) NOT NULL DEFAULT 'available',
  `skills` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`skills`)),
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_employee_id_unique` (`employee_id`),
  KEY `users_role_id_index` (`role_id`),
  KEY `users_is_active_index` (`is_active`),
  KEY `users_customer_id_index` (`customer_id`),
  CONSTRAINT `users_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL,
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin User','admin@gemarcph.com','2026-03-02 02:33:18','$2y$12$KwWYbJ28NaDiml43nugRkOTFuXtN0V.mo9KzoyRw8rloS6coRYS5W',1,NULL,'Administration',NULL,NULL,NULL,1,'2026-03-15 23:48:58','available',NULL,NULL,'2026-03-02 02:33:18','2026-03-15 23:48:58'),(2,'Maam Jhen','marketing@gemarcph.com','2026-03-02 02:33:19','$2y$12$yfy9qbyW2zlc01uJ7/92tOCF9EQKz7brObF.A3Wg6agOULqhMAOkC',2,NULL,'Marketing',NULL,NULL,NULL,1,'2026-03-13 00:26:49','available',NULL,'94wnPDZXFHovkoIfSdjcUebVCZclZ9H2961XpRlrNyi5E1hNBumM0SaJQzvV','2026-03-02 02:33:19','2026-03-13 00:26:49'),(3,'James Arroyo','technician@gemarcph.com','2026-03-02 02:33:19','$2y$12$N732zXpKYndM/FhyiF6ATey/l9hQo6XIFYR4599p4tO6g18KIOeu.',3,NULL,'Technical',NULL,NULL,NULL,1,'2026-03-13 01:04:37','available',NULL,NULL,'2026-03-02 02:33:19','2026-03-13 01:04:37'),(4,'Sir Einjel','techhead@gemarcph.com','2026-03-02 02:33:19','$2y$12$VMsBScL7PGDdeLIprM9ZS.PpUksWrUbvS3lNyM1Q2fY5/.jmidS4u',4,NULL,'Technical',NULL,NULL,NULL,1,'2026-03-13 01:16:33','available',NULL,NULL,'2026-03-02 02:33:19','2026-03-13 01:16:33'),(5,'Ana Reyes','signatory@gemarcph.com','2026-03-02 02:33:19','$2y$12$Tx/JTNbxIdf.n8A8gBZtK.mFH0MyHgeXfmc11X6W7Wam0n/6WM/KO',5,NULL,'Management',NULL,NULL,NULL,1,'2026-03-13 00:36:59','available',NULL,NULL,'2026-03-02 02:33:19','2026-03-13 00:36:59'),(7,'CUSTOMER','customer@gemarcph.com','2026-02-18 23:22:01','$2y$12$OETVrNNN1Fky8MjpWr59i.KzBuc0/tiWjC7tHa4JtQ99WMpPLxHqG',14,4,NULL,NULL,NULL,NULL,1,'2026-03-12 23:41:17','available',NULL,'cQa12oQ18X90tXNGIkPRIHAc3sCGPsXR7qsAD0xuxxszAPYuIIJ9apyDmPpR','2026-02-10 23:41:47','2026-03-12 23:41:17'),(14,'Maam April','accounting@gemarcph.com','2026-03-02 02:33:19','$2y$12$uHh2iEGAk8nCooq85U.hj.Qrj1xCRBixKmv7QRRXH6yIo7L5bi8OO',15,NULL,'Accounting',NULL,NULL,NULL,1,'2026-03-12 23:43:02','available',NULL,NULL,'2026-03-02 02:33:19','2026-03-12 23:43:02');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `workload_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `workload_allocations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `date` date NOT NULL,
  `allocated_hours` decimal(5,2) NOT NULL DEFAULT 0.00,
  `available_hours` decimal(5,2) NOT NULL DEFAULT 8.00,
  `utilization_rate` decimal(5,2) NOT NULL DEFAULT 0.00,
  `assignments_count` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `workload_allocations_user_id_date_unique` (`user_id`,`date`),
  KEY `workload_allocations_user_id_index` (`user_id`),
  KEY `workload_allocations_date_index` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `workload_allocations` WRITE;
/*!40000 ALTER TABLE `workload_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `workload_allocations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

